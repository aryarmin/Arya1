﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Reflection;
using Models;
using DAL;

namespace WindowsFormsApp1
{
    public partial class frmKeyword : Form
    {
        public frmKeyword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //use reflection to read from textbox

            TextBox tbx = this.Controls.Find("textBox2", true).FirstOrDefault() as TextBox;


            var req = WebRequest.Create(tbx.Text);
            req.BeginGetResponse(r =>
            {
                var response = req.EndGetResponse(r);
                var stream = response.GetResponseStream();
                var reader = new StreamReader(stream, true);
                var str = reader.ReadToEnd();
                // search for keyword



                string b = " ";

                string[] split_text = str.Split(Convert.ToChar(b));
                int space_count = 0;


                for (int i = 0; i < split_text.Length; i++)
                {
                    if (Regex.Match(split_text[i], txtKeyword.Text).Success)

                    {
                        space_count++;
                    }

                }

           
              keyword  c = new keyword();
                c.code = Convert.ToInt32(txtID.Text);
                c.keyword1 = txtKeyword.Text;
                c.number = space_count;
              
                //  insert keyword
              Keywordrepository cr = new Keywordrepository();
                cr.Insert(c);




            }, null);
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            keyword c = new keyword();
            c.code = Convert.ToInt32(txtID.Text);
            c.keyword1 = txtKeyword.Text;

            //get webaddress through textbox.2


            var req = WebRequest.Create(txtAddress.Text);
            req.BeginGetResponse(r =>
            {
                var response = req.EndGetResponse(r);
                var stream = response.GetResponseStream();
                var reader = new StreamReader(stream, true);
                var str = reader.ReadToEnd();
               



                string b = " ";

                string[] split_text = str.Split(Convert.ToChar(b));
                int space_count = 0;
               
             //   read keyword through textbox3

                for (int i = 0; i < split_text.Length; i++)
                {
                    if (Regex.Match(split_text[i], txtKeyword.Text).Success)

                    {
                        space_count++;
                    }

                }

           
               
                c.number = space_count;

                // update keyword
                Keywordrepository cr = new Keywordrepository();
                cr.Update(c);




            }, null);




        }

        private void button3_Click(object sender, EventArgs e)
        {
            Keywordrepository cr = new Keywordrepository();
            cr.Delete(Convert.ToInt32(txtID.Text));
        }
    }
}
