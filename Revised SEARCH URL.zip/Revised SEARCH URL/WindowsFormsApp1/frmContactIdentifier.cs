﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Reflection;
using Models;
using DAL;


namespace WindowsFormsApp1
{
    public partial class frmContactIdentifier : Form
    {
        public frmContactIdentifier()
        {
            InitializeComponent();
        }
        public string domain;
        private void button1_Click(object sender, EventArgs e)
        {
            Email c = new Email();
            //use Reflection

            TextBox tbx = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;

            c.code = Convert.ToInt32(tbx.Text);
            c.webpageadd = txtAddress.Text;

            var req = WebRequest.Create(txtAddress.Text);
            req.BeginGetResponse(r =>
            {
                var response = req.EndGetResponse(r);
                var stream = response.GetResponseStream();
                var reader = new StreamReader(stream, true);
                var str = reader.ReadToEnd();
             



                string b = " ";

                string[] split_text = str.Split(Convert.ToChar(b));
                int space_count = 0;
                //Identif emails in the page

                for (int i = 0; i < split_text.Length; i++)
                {
                    if (Regex.Match(split_text[i], @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*").Success)

                    {
                        space_count++;

                        //  Identify domain from websiteaddress

                        c.line += split_text[i].ToString();
                        Match match = Regex.Match(txtAddress.Text, @"^(?:\w+://)?([^/?]*)");
                        domain = match.Groups[1].Value;


                    }

                }
               


                c.domainname = domain;
                c.count = space_count;

               
                Emailrepoitory cr = new Emailrepoitory();
                cr.Insert(c);








            }, null);
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
