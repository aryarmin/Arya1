﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ucDashboard : MetroFramework.Controls.MetroUserControl
    {
        public ucDashboard()
        {
            InitializeComponent();
        }

        private void ucDashboard_Load(object sender, EventArgs e)
        {
            mbtnAddress.BringToFront();
            mbtnAddress.Visible = true;
           
            
        }

        private void metroCategory_Click(object sender, EventArgs e)
        {
            if (!frmMain.Instance.MetroContainer.Controls.ContainsKey("ucCategory")) {

                ucCategory uc = new ucCategory();
                uc.Dock = DockStyle.Fill;
                frmMain.Instance.MetroContainer.Controls.Add(uc);

            }
            frmMain.Instance.MetroContainer.Controls["ucCategory"].BringToFront();
            frmMain.Instance.MetroBack.Visible = true;
          
           
           
            
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            frmAddress frm = new frmAddress();
            frm.Show();
        }

        private void mbtn2_Click(object sender, EventArgs e)
        {
            frmKeyword frm = new frmKeyword();
            frm.Show();
        }
    }
}
