﻿namespace WindowsFormsApp1
{
    partial class ucCategory
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mbtnLogInfo = new MetroFramework.Controls.MetroButton();
            this.mbtnContactDetails = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // mbtnLogInfo
            // 
            this.mbtnLogInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mbtnLogInfo.Location = new System.Drawing.Point(336, 144);
            this.mbtnLogInfo.Name = "mbtnLogInfo";
            this.mbtnLogInfo.Size = new System.Drawing.Size(275, 70);
            this.mbtnLogInfo.TabIndex = 0;
            this.mbtnLogInfo.Text = "Save Log Inormation";
            this.mbtnLogInfo.UseSelectable = true;
            this.mbtnLogInfo.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // mbtnContactDetails
            // 
            this.mbtnContactDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mbtnContactDetails.Location = new System.Drawing.Point(336, 306);
            this.mbtnContactDetails.Name = "mbtnContactDetails";
            this.mbtnContactDetails.Size = new System.Drawing.Size(275, 79);
            this.mbtnContactDetails.TabIndex = 1;
            this.mbtnContactDetails.Text = "Find Contact Details";
            this.mbtnContactDetails.UseSelectable = true;
            this.mbtnContactDetails.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // ucCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.mbtnContactDetails);
            this.Controls.Add(this.mbtnLogInfo);
            this.Name = "ucCategory";
            this.Size = new System.Drawing.Size(954, 528);
            this.Load += new System.EventHandler(this.ucCategory_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton mbtnLogInfo;
        private MetroFramework.Controls.MetroButton mbtnContactDetails;
    }
}
