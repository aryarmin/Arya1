﻿namespace WindowsFormsApp1
{
    partial class ucDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroCategory = new MetroFramework.Controls.MetroTile();
            this.mbtnAddress = new MetroFramework.Controls.MetroButton();
            this.mbtnKeyword = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroCategory
            // 
            this.metroCategory.ActiveControl = null;
            this.metroCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroCategory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroCategory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroCategory.Location = new System.Drawing.Point(3, 3);
            this.metroCategory.Name = "metroCategory";
            this.metroCategory.Size = new System.Drawing.Size(323, 40);
            this.metroCategory.Style = MetroFramework.MetroColorStyle.Green;
            this.metroCategory.TabIndex = 0;
            this.metroCategory.Text = "Identifier of contact parts of websites";
            this.metroCategory.TileImage = global::WindowsFormsApp1.Properties.Resources.if_arrow_left_square_black_243653;
            this.metroCategory.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.metroCategory.UseSelectable = true;
            this.metroCategory.Click += new System.EventHandler(this.metroCategory_Click);
            // 
            // mbtnAddress
            // 
            this.mbtnAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mbtnAddress.Location = new System.Drawing.Point(331, 325);
            this.mbtnAddress.Name = "mbtnAddress";
            this.mbtnAddress.Size = new System.Drawing.Size(235, 88);
            this.mbtnAddress.TabIndex = 1;
            this.mbtnAddress.Text = "Save Website Address";
            this.mbtnAddress.UseSelectable = true;
            this.mbtnAddress.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // mbtnKeyword
            // 
            this.mbtnKeyword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mbtnKeyword.Location = new System.Drawing.Point(331, 143);
            this.mbtnKeyword.Name = "mbtnKeyword";
            this.mbtnKeyword.Size = new System.Drawing.Size(235, 84);
            this.mbtnKeyword.TabIndex = 2;
            this.mbtnKeyword.Text = "Find keywords in Websites";
            this.mbtnKeyword.UseSelectable = true;
            this.mbtnKeyword.Click += new System.EventHandler(this.mbtn2_Click);
            // 
            // ucDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.mbtnKeyword);
            this.Controls.Add(this.mbtnAddress);
            this.Controls.Add(this.metroCategory);
            this.Name = "ucDashboard";
            this.Size = new System.Drawing.Size(956, 524);
            this.Load += new System.EventHandler(this.ucDashboard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTile metroCategory;
        private MetroFramework.Controls.MetroButton mbtnAddress;
        private MetroFramework.Controls.MetroButton mbtnKeyword;
    }
}
