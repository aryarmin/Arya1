﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using Models;


namespace WindowsFormsApp1
{
    public partial class frmAddress : Form
    {
        public frmAddress()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pageAddress c = new pageAddress();
            //use reflection

            TextBox tbx = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;

            c.code = Convert.ToInt32(tbx.Text);
            c.webaddress = txtAddress.Text;

            //  insert page address
            PageAddressrepository cr = new PageAddressrepository();
            cr.Insert(c);
        }

        public void button2_Click(object sender, EventArgs e)
        {
            pageAddress c = new pageAddress();
            c.code = Convert.ToInt32(txtID.Text);
            c.webaddress = txtAddress.Text;
            PageAddressrepository cr = new PageAddressrepository();
            cr.Update(c);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PageAddressrepository cr = new PageAddressrepository();
            cr.Delete(Convert.ToInt32(txtID.Text));
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void keywordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmKeyword frm = new frmKeyword();
            frm.Show();
        }

        private void identifyEmailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContactIdentifier frm = new frmContactIdentifier();
            frm.Show();
        }

        private void keywordToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmKeyword frm = new frmKeyword();
            frm.Show();

        }

        private void specifyEmailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContactIdentifier frm = new frmContactIdentifier();
            frm.Show();
        }

        private void saveLogFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSaveLog frm = new frmSaveLog();
            frm.Show();
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {


        }
    }
}
