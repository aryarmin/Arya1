﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;


namespace WindowsFormsApp1
{
    public partial class frmMain : MetroFramework.Forms.MetroForm



    {

        static frmMain _instance;
        public static frmMain Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new frmMain();
                return _instance;


            }


        }

        public MetroFramework.Controls.MetroPanel MetroContainer

        {


            get { return mpanel; }
            set { mpanel = value; }


}


        public MetroFramework .Controls.MetroLink MetroBack
        {

            get { return mback; }

            set { mback = value; }
        }



        public frmMain()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            
            mback.Visible = false;
            _instance = this;
            ucDashboard uc = new ucDashboard();
            uc.Dock = DockStyle.Fill;
            mpanel.Controls.Add(uc);
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
           
        }

        private void mback_Click(object sender, EventArgs e)
        {
            mpanel.Controls["ucDashboard"].BringToFront();
            mback.Visible = false;
            
        }

        private void mpanel_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
