﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Reflection;
using Models;
using DAL;


namespace WindowsFormsApp1
{
    public partial class frmSaveLog : Form
    {
        public frmSaveLog()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            //measure time to get response for each page
            log l = new log ();
            WebRequest webRequest = WebRequest.Create(txtAddress.Text);
            System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch();
            timer.Start();
            WebResponse webResponse;

      
                webResponse = webRequest.GetResponse();
            
                timer.Stop();
                    var stream = webResponse.GetResponseStream();
                

                var reader = new StreamReader(stream, true);
                var str = reader.ReadToEnd();


                byte[] result;
 //insert file into database(convrt stream to varbinary)              

using (var streamReader = new MemoryStream())
                { 

stream.CopyTo(streamReader);
 
result = streamReader.ToArray();
                    l.context = result;
}

//use reflection
            TextBox tbx = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;
            

            l.code = Convert.ToInt32(tbx.Text);
                l.processtime = timer.Elapsed;
                l.ifexists = true;
              
  //time now inert into D.B              
                DateTime myDateTime = DateTime.Now;
               l.loadtime = myDateTime.Date.ToString("yyyy-MM-dd HH:mm:ss");








            
                Logrepository cr = new Logrepository();
                cr.Insert(l);
     
        }
    }
}
