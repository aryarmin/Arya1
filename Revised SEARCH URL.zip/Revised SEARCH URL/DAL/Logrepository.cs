﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    public class Logrepository: ILogrepository
    {
        private searchURLEntities db;


        private List<pageAddress> data1 = new List<pageAddress>();


        public Logrepository()
        {
            this.db = new searchURLEntities();
        }

        public Logrepository(searchURLEntities db)
        {
            this.db = db;
        }

        public IEnumerable<log> SelectAll()
        {

            return db.logs.ToList();
        }

        public log SelectByID(int id)
        {
            pageAddress c = new pageAddress();
            return db.logs.Find(id);



        }
        public log SelectBylogID(int logID)
        {

            return db.logs.Find(logID);
        }


        public void Insert(log c)
        {



            db.logs.Add(c);


            db.SaveChanges();



        }

        public void Update(log c)
        {

            var st = db.logs.FirstOrDefault(h => h.code == c.code);

            st.context = c.context;
            st.processtime = c.processtime;
         //   stud.loadtime = c.loadtime;
           
            st.ifexists = c.ifexists;




            db.Entry(st).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

        }

        public void Delete(int n)
        {

            log c = new log();
            var st = db.logs.FirstOrDefault(g => g.code == n);


            db.logs.Remove(st);




            db.SaveChanges();

        }

        public void Save()
        {
            db.SaveChanges();
        }
    }
}
