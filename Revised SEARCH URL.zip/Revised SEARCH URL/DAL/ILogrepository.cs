﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;


namespace DAL
{
    interface ILogrepository
    {
        IEnumerable<log> SelectAll();
        log SelectByID(int id);
        log SelectBylogID(int logid);

        void Insert(log k);
        void Update(log k);
        void Delete(int n);
        void Save();

    }
}
