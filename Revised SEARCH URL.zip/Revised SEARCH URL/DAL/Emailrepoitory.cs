﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;


namespace DAL
{
   public class Emailrepoitory: IEmailrepository
    {

        private searchURLEntities db;


        private List<pageAddress> data1 = new List<pageAddress>();


        public Emailrepoitory()
        {
            this.db = new searchURLEntities();
        }

        public Emailrepoitory(searchURLEntities db)
        {
            this.db = db;
        }

        public IEnumerable<Email> SelectAll()
        {

            return db.Emails.ToList();
        }

        public Email SelectByID(int id)
        {
            pageAddress c = new pageAddress();
            return db.Emails.Find(id);



        }
        public Email SelectByemailID(int emailID)
        {

            return db.Emails.Find(emailID);
        }


        public void Insert(Email c)
        {



            db.Emails.Add(c);


            db.SaveChanges();



        }

        public void Update(Email c)
        {

            var st = db.Emails.FirstOrDefault(h => h.code == c.code);

            st.webpageadd = c.webpageadd;
            st.domainname = c.domainname;
            st.line = c.line;


            db.Entry(st).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

        }

        public void Delete(int n)
        {

            Email c = new Email();
            var st = db.Emails.FirstOrDefault(g => g.code == n);


            db.Emails.Remove(st);




            db.SaveChanges();

        }

        public void Save()
        {
            db.SaveChanges();
        }
    }
}

