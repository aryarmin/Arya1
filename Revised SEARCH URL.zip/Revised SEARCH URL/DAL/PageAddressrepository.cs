﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace DAL
{
  public class PageAddressrepository: IPageadressrepository
    {
        private searchURLEntities db;
        

        private List<pageAddress> data1 = new List<pageAddress>();


        public PageAddressrepository()
        {
            this.db = new searchURLEntities();
        }

        public PageAddressrepository(searchURLEntities db)
        {
            this.db = db;
        }

        public IEnumerable<pageAddress> SelectAll()
        {

            return db.pageAddresses.ToList();
            }

        public pageAddress SelectByID(int id)
        {
            pageAddress c = new pageAddress();
            return db.pageAddresses.Find(id);



        }
        public pageAddress SelectBypageID(int Id)
        {

            return db.pageAddresses.Find(Id);
        }


        public void Insert(pageAddress c)
        {



            db.pageAddresses.Add(c);


            db.SaveChanges();



        }

        public void Update(pageAddress c)
        {

            var st = db.pageAddresses.FirstOrDefault(h => h.code == c.code);

            st.webaddress = c.webaddress;
           


            db.Entry(st).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

        }

        public void Delete(int n)
        {

            pageAddress c = new pageAddress();
            var stud = db.pageAddresses.FirstOrDefault(g => g.code == n);


            db.pageAddresses.Remove(stud);




            db.SaveChanges();

        }

        public void Save()
        {
            db.SaveChanges();
        }
    }
}

    