﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace DAL
{
    interface IPageadressrepository
    {
        IEnumerable<pageAddress> SelectAll();
        pageAddress SelectByID(int id);
        pageAddress SelectBypageID(int Id);

        void Insert(pageAddress p);
        void Update(pageAddress p);
        void Delete(int n);
        void Save();
    }
}
