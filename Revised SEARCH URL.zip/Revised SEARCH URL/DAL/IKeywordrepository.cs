﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Models;

namespace DAL
{
    interface IKeywordrepository
    {
        IEnumerable<keyword> SelectAll();
        keyword SelectByID(int id);
        keyword SelectBykeywordID(int keywordid);

        void Insert(keyword k);
        void Update(keyword k);
        void Delete(int n);
        void Save();
    }
}
