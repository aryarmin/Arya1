﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;


namespace DAL
{
    interface IEmailrepository
    {
        IEnumerable<Email> SelectAll();
        Email SelectByID(int id);
        Email SelectByemailID(int courseid);

        void Insert(Email k);
        void Update(Email k);
        void Delete(int n);
        void Save();
    }
}
