﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;


namespace DAL
{
  public class Keywordrepository:IKeywordrepository
    {
        private searchURLEntities db;


        private List<pageAddress> data1 = new List<pageAddress>();


        public Keywordrepository()
        {
            this.db = new searchURLEntities();
        }

        public Keywordrepository(searchURLEntities db)
        {
            this.db = db;
        }

        public IEnumerable<keyword> SelectAll()
        {

            return db.keywords.ToList();
        }

        public keyword SelectByID(int id)
        {
          keyword c = new keyword();
            return db.keywords.Find(id);



        }
        public keyword SelectBykeywordID(int keywordID)
        {

            return db.keywords.Find(keywordID);
        }


        public void Insert(keyword c)
        {



            db.keywords.Add(c);


            db.SaveChanges();



        }

        public void Update(keyword c)
        {

            var st = db.keywords.FirstOrDefault(h => h.code == c.code);

            st.keyword1 = c.keyword1;
            st.number = c.number;



            db.Entry(st).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

        }

        public void Delete(int n)
        {

            keyword c = new keyword();
            var st = db.keywords.FirstOrDefault(g => g.code == n);


            db.keywords.Remove(st);




            db.SaveChanges();

        }

        public void Save()
        {
            db.SaveChanges();
        }
    }
}

